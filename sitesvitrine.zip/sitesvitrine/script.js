const textElement = document.querySelector('.text');
const backgroundElement = document.querySelector('.content');

backgroundElement.addEventListener('animationiteration',() => {
    if (backgroundElement.style.backgroundImage.includes('images/nettoyage2.jpg')){
        textElement.textContent = 'Entretiens, Nettoyages, Jardinage';
    } else if (backgroundElement.style.backgroundImage.includes('images/securite.png')){
        textElement.textContent = 'Gardiennage Sécurité';
    
    }else if (backgroundElement.style.backgroundImage.includes('images/palmares-autocars.jpg')){
        textElement.textContent = 'Tranport';
    }else if (backgroundElement.style.backgroundImage.includes('images/img-homepage@1062.jpg')){
        textElement.textContent = 'Savonnerie';
    }


});
console.log(textElement)